/* JavaScript */

function isPrime(num) {

    // keep this condition as-is, you can refer for syntax
    if (num < 0) {
        return isPrime(-num);
    }

    // Start

    // End

    var i = 2;
    while (
        // Start
        0 // this has been added to remove error of compiling, you need to write correct code
        // End
    ) {
        // Start

        // End
    }

    // Start

    // End

}
